# ExamPilot — Android exam planner

ExamPilot is an offline-first Flutter app for entering exam dates, subjects, chapter lists, target percentage and daily routine; generating a suggested daily study plan; tracking chapter completion/revision; and recording marks with optional result-image attachments.

## Build the APK through GitHub

1. Create a new repository on GitHub.
2. Upload the **contents** of this folder to the repository root (the `.github` folder must be included). The workflow generates the standard Android project files during the build.
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Run **Build Android APK** using **Run workflow**, or push a commit to `main`.
5. Open the completed workflow run. Under **Artifacts**, download `exampilot-release-apk`.
6. Extract the downloaded ZIP. Install `app-release.apk` on your Android phone. Android may ask you to allow installation from that source.

To publish an APK under GitHub **Releases**, create and push a version tag, for example:
`git tag v1.0.0 && git push origin v1.0.0`

## Features

- Exam dates and multiple subjects per exam.
- Chapter entries with weightage and difficulty (1–5).
- Daily routine: wake, breakfast, lunch, dinner, sleep, study-session length.
- Target percentage setting.
- Suggested timetable based on the nearest upcoming exam and pending chapter priority.
- Chapter completion and revision checkboxes.
- Marks record with optional image attachment.
- Local persistence using SharedPreferences; result images are stored in app-private storage.

## Chapter entry format

When adding a subject, enter one chapter per line:
`Chapter name | weightage | difficulty`

Example:
`Electrostatics | 5 | 4`

Weightage is a relative priority value, not an official prediction of exam marks. Difficulty is from 1 (easy) to 5 (hard).

## Important notes

- This first version creates a deterministic study plan; it does not use a cloud AI model.
- The planner uses the nearest upcoming exam, chapter weightage and difficulty. It is a planning aid, not a guarantee of a particular board percentage.
- Data is stored locally on the device. Uninstalling the app or clearing its storage can erase records. Export/backup and cloud sync are not included in this starter version.
- Before a production release, set a permanent Android application ID and app icon, and test on your target Android device.
