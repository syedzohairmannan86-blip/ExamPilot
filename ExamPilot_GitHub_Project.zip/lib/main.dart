import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = ExamStore();
  await store.load();
  runApp(ExamPilotApp(store: store));
}

const ink = Color(0xFF14213D);
const blue = Color(0xFF3157D5);
const canvas = Color(0xFFF4F6FB);
const muted = Color(0xFF68738A);

class ExamPilotApp extends StatelessWidget {
  final ExamStore store;
  const ExamPilotApp({super.key, required this.store});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'ExamPilot',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: canvas,
      colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.light),
      appBarTheme: const AppBarTheme(backgroundColor: canvas, foregroundColor: ink, elevation: 0),
      cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xFFF7F8FC),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      ),
    ),
    home: HomePage(store: store),
  );
}

class Chapter {
  String name;
  double weight;
  int difficulty; // 1-5
  bool done;
  bool revised;
  Chapter(this.name, this.weight, this.difficulty, {this.done = false, this.revised = false});
  Map<String, dynamic> toJson() => {'name': name, 'weight': weight, 'difficulty': difficulty, 'done': done, 'revised': revised};
  factory Chapter.fromJson(Map<String, dynamic> j) => Chapter(j['name'] ?? '', (j['weight'] ?? 1).toDouble(), j['difficulty'] ?? 3, done: j['done'] ?? false, revised: j['revised'] ?? false);
}

class Subject {
  String name;
  double maxMarks;
  List<Chapter> chapters;
  Subject(this.name, this.maxMarks, this.chapters);
  Map<String, dynamic> toJson() => {'name': name, 'maxMarks': maxMarks, 'chapters': chapters.map((e) => e.toJson()).toList()};
  factory Subject.fromJson(Map<String, dynamic> j) => Subject(j['name'] ?? '', (j['maxMarks'] ?? 100).toDouble(), (j['chapters'] as List? ?? []).map((e) => Chapter.fromJson(Map<String,dynamic>.from(e))).toList());
}

class Exam {
  String name;
  DateTime date;
  List<Subject> subjects;
  Exam(this.name, this.date, this.subjects);
  Map<String, dynamic> toJson() => {'name': name, 'date': date.toIso8601String(), 'subjects': subjects.map((e) => e.toJson()).toList()};
  factory Exam.fromJson(Map<String, dynamic> j) => Exam(j['name'] ?? 'Exam', DateTime.tryParse(j['date'] ?? '') ?? DateTime.now(), (j['subjects'] as List? ?? []).map((e) => Subject.fromJson(Map<String,dynamic>.from(e))).toList());
}

class ExamResult {
  String examName;
  String subject;
  double obtained;
  double maximum;
  String date;
  String? imagePath;
  ExamResult(this.examName, this.subject, this.obtained, this.maximum, this.date, this.imagePath);
  double get percent => maximum <= 0 ? 0 : obtained / maximum * 100;
  Map<String,dynamic> toJson() => {'examName': examName, 'subject': subject, 'obtained': obtained, 'maximum': maximum, 'date': date, 'imagePath': imagePath};
  factory ExamResult.fromJson(Map<String,dynamic> j) => ExamResult(j['examName'] ?? '', j['subject'] ?? '', (j['obtained'] ?? 0).toDouble(), (j['maximum'] ?? 100).toDouble(), j['date'] ?? '', j['imagePath']);
}

class Routine {
  String wake = '06:00';
  String breakfast = '10:00';
  String lunch = '14:00';
  String dinner = '22:30';
  String sleep = '03:00';
  int sessionMinutes = 75;
  double target = 95;
  Map<String,dynamic> toJson() => {'wake':wake,'breakfast':breakfast,'lunch':lunch,'dinner':dinner,'sleep':sleep,'sessionMinutes':sessionMinutes,'target':target};
  void fromJson(Map<String,dynamic> j) {
    wake=j['wake']??wake; breakfast=j['breakfast']??breakfast; lunch=j['lunch']??lunch; dinner=j['dinner']??dinner; sleep=j['sleep']??sleep;
    sessionMinutes=j['sessionMinutes']??sessionMinutes; target=(j['target']??target).toDouble();
  }
}

class StudyTask {
  String time;
  String subject;
  String chapter;
  String activity;
  int minutes;
  bool done;
  StudyTask(this.time,this.subject,this.chapter,this.activity,this.minutes,{this.done=false});
}

class ExamStore extends ChangeNotifier {
  List<Exam> exams = [];
  List<ExamResult> results = [];
  Routine routine = Routine();
  List<StudyTask> tasks = [];
  DateTime taskDate = DateTime.now();

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    try {
      exams = (jsonDecode(p.getString('exams') ?? '[]') as List).map((e)=>Exam.fromJson(Map<String,dynamic>.from(e))).toList();
      results = (jsonDecode(p.getString('results') ?? '[]') as List).map((e)=>ExamResult.fromJson(Map<String,dynamic>.from(e))).toList();
      routine.fromJson(jsonDecode(p.getString('routine') ?? '{}'));
    } catch (_) {}
    generatePlan();
  }
  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('exams', jsonEncode(exams.map((e)=>e.toJson()).toList()));
    await p.setString('results', jsonEncode(results.map((e)=>e.toJson()).toList()));
    await p.setString('routine', jsonEncode(routine.toJson()));
    notifyListeners();
  }
  void addExam(Exam e) { exams.add(e); save(); generatePlan(); }
  void deleteExam(Exam e) { exams.remove(e); save(); generatePlan(); }
  void addResult(ExamResult r) { results.add(r); save(); }
  void toggleChapter(Chapter c, bool revised) { if (revised) { c.revised=!c.revised; } else { c.done=!c.done; } save(); generatePlan(); }

  int _mins(String t) { final a=t.split(':'); return int.parse(a[0])*60+int.parse(a[1]); }
  String _clock(int m) {
    m = m % 1440;
    final h=(m~/60)%24, mm=m%60;
    final suffix=h>=12?'PM':'AM';
    final hh=h%12==0?12:h%12;
    return '$hh:${mm.toString().padLeft(2,'0')} $suffix';
  }
  void generatePlan() {
    tasks = [];
    final now=DateTime.now();
    taskDate=DateTime(now.year,now.month,now.day);
    if (exams.isEmpty) return;
    final upcoming=exams.where((e)=>!e.date.isBefore(DateTime(now.year,now.month,now.day))).toList()..sort((a,b)=>a.date.compareTo(b.date));
    if (upcoming.isEmpty) return;
    final exam=upcoming.first;
    final pool=<Map<String,dynamic>>[];
    for (final s in exam.subjects) {
      for (final c in s.chapters.where((c)=>!c.done)) {
        final days=max(1,exam.date.difference(taskDate).inDays+1);
        final score=(c.weight * c.difficulty) / days;
        pool.add({'s':s.name,'c':c.name,'score':score,'weight':c.weight,'difficulty':c.difficulty});
      }
    }
    pool.sort((a,b)=>(b['score'] as double).compareTo(a['score'] as double));
    if (pool.isEmpty) return;
    final wake=_mins(routine.wake), breakfast=_mins(routine.breakfast), lunch=_mins(routine.lunch), dinner=_mins(routine.dinner);
    var sleep=_mins(routine.sleep);
    if (sleep <= wake) sleep += 1440;
    final blocks=<List<int>>[];
    void addBlock(int a,int b) { if (b>a) blocks.add([a,b]); }
    addBlock(wake,breakfast-30);
    addBlock(breakfast+45,lunch-30);
    addBlock(lunch+60,dinner-30);
    addBlock(dinner+60,sleep);
    var index=0;
    for (final block in blocks) {
      var cursor=block[0];
      while (cursor + 30 <= block[1] && index < pool.length * 3) {
        final mins=min(routine.sessionMinutes, block[1]-cursor);
        if (mins < 30) break;
        final item=pool[index % pool.length];
        final acts=['Concept learning + NCERT','Solved examples / numericals','Active recall + short notes','Derivations / important questions','Timed practice + error review'];
        tasks.add(StudyTask(_clock(cursor),item['s'],item['c'],acts[index % acts.length],mins));
        cursor += mins + 15;
        index++;
      }
    }
    if (tasks.isEmpty) {
      tasks.add(StudyTask(_clock(wake),'Planning','Set routine','Add realistic meal times and a longer study window',30));
    }
  }
  double get completion {
    final all=exams.expand((e)=>e.subjects).expand((s)=>s.chapters).toList();
    if (all.isEmpty) return 0;
    return all.where((c)=>c.done).length/all.length*100;
  }
  double get average {
    if (results.isEmpty) return 0;
    return results.map((r)=>r.percent).reduce((a,b)=>a+b)/results.length;
  }
}

class HomePage extends StatefulWidget {
  final ExamStore store;
  const HomePage({super.key,required this.store});
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab=0;
  @override Widget build(BuildContext context) {
    return AnimatedBuilder(animation:widget.store,builder:(context,_)=>Scaffold(
      appBar: AppBar(title: Row(children:[Container(width:34,height:34,decoration:BoxDecoration(color:blue,borderRadius:BorderRadius.circular(11)),child:const Icon(Icons.school_rounded,color:Colors.white,size:20)),const SizedBox(width:10),const Text('ExamPilot',style:TextStyle(fontWeight:FontWeight.w800,letterSpacing:-.5))]), actions:[IconButton(onPressed:()=>showRoutine(context,widget.store),icon:const Icon(Icons.tune_rounded))]),
      body: IndexedStack(index:tab,children:[
        Dashboard(store:widget.store,onGo:(i)=>setState(()=>tab=i)),
        Planner(store:widget.store),
        ExamsPage(store:widget.store),
        ResultsPage(store:widget.store),
      ]),
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const[
        NavigationDestination(icon:Icon(Icons.grid_view_rounded),label:'Home'),
        NavigationDestination(icon:Icon(Icons.calendar_month_rounded),label:'Planner'),
        NavigationDestination(icon:Icon(Icons.menu_book_rounded),label:'Exams'),
        NavigationDestination(icon:Icon(Icons.analytics_rounded),label:'Results'),
      ]),
    ));
  }
}

class Dashboard extends StatelessWidget {
  final ExamStore store; final ValueChanged<int> onGo;
  const Dashboard({super.key,required this.store,required this.onGo});
  @override Widget build(BuildContext context) {
    final all=store.exams.expand((e)=>e.subjects).expand((s)=>s.chapters).length;
    final next=store.exams.where((e)=>!e.date.isBefore(DateTime.now().subtract(const Duration(days:1)))).toList()..sort((a,b)=>a.date.compareTo(b.date));
    final exam=next.isEmpty?null:next.first;
    return ListView(padding:const EdgeInsets.fromLTRB(18,8,18,24),children:[
      Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(gradient:const LinearGradient(colors:[ink,Color(0xFF263F78)],begin:Alignment.topLeft,end:Alignment.bottomRight),borderRadius:BorderRadius.circular(24)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('YOUR TARGET',style:TextStyle(color:Color(0xFFB9C8EA),fontSize:11,fontWeight:FontWeight.bold,letterSpacing:1.4)),
        const SizedBox(height:7),Text('${store.routine.target.toStringAsFixed(0)}%',style:const TextStyle(color:Colors.white,fontSize:38,fontWeight:FontWeight.w800)),
        const Text('Build consistency. Track every improvement.',style:TextStyle(color:Color(0xFFD5DDF0),fontSize:13)),
        const SizedBox(height:18),Row(children:[_miniStat('SYLLABUS','${store.completion.toStringAsFixed(0)}%'),const SizedBox(width:25),_miniStat('RECORDED AVG','${store.average.toStringAsFixed(1)}%')])
      ])),
      const SizedBox(height:18),
      Row(children:[Expanded(child:_sectionTitle('Next examination')),TextButton(onPressed:()=>onGo(2),child:const Text('View all'))]),
      if(exam==null) _emptyCard('No examination added','Add an exam date and syllabus to generate your plan.')
      else _examCard(exam),
      const SizedBox(height:18),
      Row(children:[Expanded(child:_sectionTitle("Today's focus")),TextButton(onPressed:()=>onGo(1),child:const Text('Open planner'))]),
      if(store.tasks.isEmpty) _emptyCard('Your plan is waiting','Add an upcoming exam with at least one pending chapter.')
      else ...store.tasks.take(4).map((t)=>_taskTile(t)),
      const SizedBox(height:18),
      _sectionTitle('Quick actions'),
      Row(children:[
        Expanded(child:_actionCard(Icons.add_circle_outline,'Add exam',()=>onGo(2))),
        const SizedBox(width:10),
        Expanded(child:_actionCard(Icons.edit_calendar_outlined,'Set routine',()=>showRoutine(context,store))),
        const SizedBox(width:10),
        Expanded(child:_actionCard(Icons.upload_file_outlined,'Add marks',()=>onGo(3))),
      ]),
    ]);
  }
  Widget _miniStat(String a,String b)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:Color(0xFFB9C8EA),fontSize:9,fontWeight:FontWeight.bold,letterSpacing:1)),Text(b,style:const TextStyle(color:Colors.white,fontSize:18,fontWeight:FontWeight.bold))]);
  Widget _sectionTitle(String s)=>Text(s,style:const TextStyle(color:ink,fontSize:17,fontWeight:FontWeight.w800));
  Widget _examCard(Exam e) {
    final days=e.date.difference(DateTime.now()).inDays;
    return Card(child:Padding(padding:const EdgeInsets.all(16),child:Row(children:[
      Container(width:48,height:52,decoration:BoxDecoration(color:const Color(0xFFEAF0FF),borderRadius:BorderRadius.circular(14)),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(DateFormat('dd').format(e.date),style:const TextStyle(color:blue,fontWeight:FontWeight.w800,fontSize:18)),Text(DateFormat('MMM').format(e.date).toUpperCase(),style:const TextStyle(color:blue,fontSize:9,fontWeight:FontWeight.bold))])),
      const SizedBox(width:13),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(e.name,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:15)),Text('${e.subjects.length} subjects · ${days<0?0:days} days remaining',style:const TextStyle(color:muted,fontSize:12))])),
      const Icon(Icons.arrow_forward_ios_rounded,size:15,color:muted)
    ])));
  }
  Widget _emptyCard(String title,String sub)=>Card(child:Padding(padding:const EdgeInsets.all(17),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:4),Text(sub,style:const TextStyle(color:muted,fontSize:12))])));
  Widget _taskTile(StudyTask t)=>Card(child:ListTile(dense:true,leading:Container(width:43,height:43,decoration:BoxDecoration(color:const Color(0xFFEAF0FF),borderRadius:BorderRadius.circular(12)),child:Center(child:Text(t.time.split(' ').first,style:const TextStyle(color:blue,fontWeight:FontWeight.bold,fontSize:11)))),title:Text(t.chapter,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${t.subject} · ${t.activity}',maxLines:1,overflow:TextOverflow.ellipsis),trailing:Text('${t.minutes}m',style:const TextStyle(color:muted,fontSize:11))));
  Widget _actionCard(IconData icon,String label,VoidCallback fn)=>InkWell(onTap:fn,borderRadius:BorderRadius.circular(16),child:Card(child:Padding(padding:const EdgeInsets.symmetric(vertical:17,horizontal:6),child:Column(children:[Icon(icon,color:blue),const SizedBox(height:7),Text(label,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w600))]))));
}

class Planner extends StatefulWidget { final ExamStore store; const Planner({super.key,required this.store}); @override State<Planner> createState()=>_PlannerState(); }
class _PlannerState extends State<Planner> {
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Daily study plan',style:TextStyle(fontSize:23,fontWeight:FontWeight.w800,color:ink)),
    const SizedBox(height:5),Text(DateFormat('EEEE, d MMMM yyyy').format(DateTime.now()),style:const TextStyle(color:muted)),
    const SizedBox(height:16),
    Card(child:Padding(padding:const EdgeInsets.all(15),child:Row(children:[const Icon(Icons.auto_awesome,color:blue),const SizedBox(width:10),const Expanded(child:Text('Plan prioritises the nearest exam and pending chapters using chapter weight and difficulty.',style:TextStyle(fontSize:12,color:muted))),TextButton(onPressed:()=>showRoutine(context,widget.store),child:const Text('Routine'))]))),
    const SizedBox(height:12),
    if(widget.store.tasks.isEmpty) const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('No plan available. Add an upcoming exam and pending chapters first.')))
    else ...widget.store.tasks.map((t)=>Card(child:CheckboxListTile(value:t.done,onChanged:(v)=>setState(()=>t.done=v??false),secondary:Container(width:46,height:46,decoration:BoxDecoration(color:const Color(0xFFEAF0FF),borderRadius:BorderRadius.circular(13)),child:Center(child:Text(t.time.split(' ').first,style:const TextStyle(color:blue,fontWeight:FontWeight.bold,fontSize:10)))),title:Text(t.chapter,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${t.subject} · ${t.activity} · ${t.minutes} min',style:const TextStyle(fontSize:11,color:muted))))),
    const SizedBox(height:12),const Text('Planning note: generated sessions are suggestions. Adjust your routine and chapter status as your preparation changes.',style:TextStyle(color:muted,fontSize:11))
  ]);
}

class ExamsPage extends StatefulWidget { final ExamStore store; const ExamsPage({super.key,required this.store}); @override State<ExamsPage> createState()=>_ExamsPageState(); }
class _ExamsPageState extends State<ExamsPage> {
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    Row(children:[const Expanded(child:Text('Exams & syllabus',style:TextStyle(fontSize:23,fontWeight:FontWeight.w800,color:ink))),FilledButton.icon(onPressed:()=>showExamDialog(context,widget.store),icon:const Icon(Icons.add,size:18),label:const Text('Add exam'))]),
    const SizedBox(height:8),const Text('Track chapters, weightage, difficulty and revision status.',style:TextStyle(color:muted,fontSize:12)),
    const SizedBox(height:14),
    if(widget.store.exams.isEmpty) const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('No exams yet. Add your first examination.')))
    else ...widget.store.exams.map((e)=>Card(child:ExpansionTile(title:Text(e.name,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${DateFormat('d MMM yyyy').format(e.date)} · ${e.subjects.length} subjects'),trailing:IconButton(icon:const Icon(Icons.delete_outline,color:muted),onPressed:()=>widget.store.deleteExam(e)),children:e.subjects.map((s)=>Padding(padding:const EdgeInsets.fromLTRB(14,0,14,12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('${s.name} · ${s.maxMarks.toStringAsFixed(0)} marks',style:const TextStyle(fontWeight:FontWeight.w700,color:blue)),
      ...s.chapters.map((c)=>Row(children:[Expanded(child:Text('${c.name}  ·  Wt ${c.weight}  ·  Difficulty ${c.difficulty}',style:const TextStyle(fontSize:11))),Checkbox(value:c.done,onChanged:(v)=>setState(()=>widget.store.toggleChapter(c,false))),const Text('Done',style:TextStyle(fontSize:10)),Checkbox(value:c.revised,onChanged:(v)=>setState(()=>widget.store.toggleChapter(c,true))),const Text('Rev.',style:TextStyle(fontSize:10))])),
    ]))).toList()))),
  ]);
}

class ResultsPage extends StatefulWidget { final ExamStore store; const ResultsPage({super.key,required this.store}); @override State<ResultsPage> createState()=>_ResultsPageState(); }
class _ResultsPageState extends State<ResultsPage> {
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    Row(children:[const Expanded(child:Text('Performance',style:TextStyle(fontSize:23,fontWeight:FontWeight.w800,color:ink))),FilledButton.icon(onPressed:()=>showResultDialog(context,widget.store),icon:const Icon(Icons.add,size:18),label:const Text('Add result'))]),
    const SizedBox(height:14),
    Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:ink,borderRadius:BorderRadius.circular(22)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('AVERAGE RECORDED SCORE',style:TextStyle(color:Color(0xFFB9C8EA),fontSize:10,letterSpacing:1,fontWeight:FontWeight.bold)),Text('${widget.store.average.toStringAsFixed(2)}%',style:const TextStyle(color:Colors.white,fontSize:34,fontWeight:FontWeight.w800)),Text('Target: ${widget.store.routine.target.toStringAsFixed(0)}%',style:const TextStyle(color:Color(0xFFD5DDF0),fontSize:12))])),
    const SizedBox(height:16),
    if(widget.store.results.isEmpty) const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('No marks recorded. Add a result manually and attach a result image if available.')))
    else ...widget.store.results.reversed.map((r)=>Card(child:ListTile(leading:const CircleAvatar(backgroundColor:Color(0xFFEAF0FF),child:Icon(Icons.assessment_outlined,color:blue)),title:Text('${r.subject} · ${r.examName}',style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${r.obtained}/${r.maximum} marks · ${r.date}'),trailing:Text('${r.percent.toStringAsFixed(1)}%',style:const TextStyle(color:blue,fontWeight:FontWeight.w800)),onTap:r.imagePath==null?null:()=>showDialog(context:context,builder:(_)=>Dialog(child:ClipRRect(borderRadius:BorderRadius.circular(18),child:Image.file(File(r.imagePath!),fit:BoxFit.contain))))))),
    const SizedBox(height:8),const Text('Your records stay on this device. Keep a separate backup of important result images.',style:TextStyle(color:muted,fontSize:11))
  ]);
}

Future<void> showRoutine(BuildContext context, ExamStore store) async {
  final r=store.routine;
  final target=TextEditingController(text:r.target.toString());
  final session=TextEditingController(text:r.sessionMinutes.toString());
  Future<String?> pick(String label,String initial) async {
    final p=initial.split(':'); final t=await showTimePicker(context:context,initialTime:TimeOfDay(hour:int.parse(p[0]),minute:int.parse(p[1])));
    if(t==null)return null; return '${t.hour.toString().padLeft(2,'0')}:${t.minute.toString().padLeft(2,'0')}';
  }
  await showDialog(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,set)=>AlertDialog(title:const Text('Daily routine & target'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
    _timeRow('Wake up',r.wake,(v)=>set(()=>r.wake=v),pick),
    _timeRow('Breakfast',r.breakfast,(v)=>set(()=>r.breakfast=v),pick),
    _timeRow('Lunch',r.lunch,(v)=>set(()=>r.lunch=v),pick),
    _timeRow('Dinner',r.dinner,(v)=>set(()=>r.dinner=v),pick),
    _timeRow('Sleep',r.sleep,(v)=>set(()=>r.sleep=v),pick),
    const SizedBox(height:10),TextField(controller:target,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Target percentage',suffixText:'%')),
    const SizedBox(height:10),TextField(controller:session,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Study session length',suffixText:'minutes')),
  ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:(){r.target=(double.tryParse(target.text)??95).clamp(1,100).toDouble();r.sessionMinutes=(int.tryParse(session.text)??75).clamp(30,180).toInt();store.save();store.generatePlan();Navigator.pop(ctx);},child:const Text('Save routine'))])));
}
Widget _timeRow(String label,String value,ValueChanged<String> update,Future<String?> Function(String,String) pick)=>ListTile(contentPadding:EdgeInsets.zero,title:Text(label),trailing:TextButton(onPressed:()async{final v=await pick(label,value);if(v!=null)update(v);},child:Text(value)));

Future<void> showExamDialog(BuildContext context,ExamStore store) async {
  final name=TextEditingController(); DateTime date=DateTime.now().add(const Duration(days:14));
  final subjects=<Subject>[];
  await showDialog(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,set)=>AlertDialog(title:const Text('Create examination'),content:SizedBox(width:420,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
    TextField(controller:name,decoration:const InputDecoration(labelText:'Examination name',hintText:'e.g. CBSE Board Examination')),
    ListTile(contentPadding:EdgeInsets.zero,title:const Text('Exam date'),subtitle:Text(DateFormat('d MMMM yyyy').format(date)),trailing:IconButton(icon:const Icon(Icons.calendar_month),onPressed:()async{final d=await showDatePicker(context:ctx,initialDate:date,firstDate:DateTime.now().subtract(const Duration(days:365)),lastDate:DateTime.now().add(const Duration(days:3650)));if(d!=null)set(()=>date=d);})),
    const Divider(),Row(children:[const Expanded(child:Text('Subjects',style:TextStyle(fontWeight:FontWeight.bold))),TextButton.icon(onPressed:()async{final s=await subjectDialog(ctx);if(s!=null)set(()=>subjects.add(s));},icon:const Icon(Icons.add),label:const Text('Add subject'))]),
    ...subjects.map((s)=>ListTile(dense:true,title:Text(s.name),subtitle:Text('${s.chapters.length} chapters'),trailing:IconButton(icon:const Icon(Icons.close),onPressed:()=>set(()=>subjects.remove(s)))))
  ]))),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:(){if(name.text.trim().isEmpty||subjects.isEmpty)return;store.addExam(Exam(name.text.trim(),date,subjects));Navigator.pop(ctx);},child:const Text('Save exam'))])));
}

Future<Subject?> subjectDialog(BuildContext context) async {
  final name=TextEditingController(), max=TextEditingController(text:'100'), chapters=TextEditingController();
  final result=await showDialog<Subject>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Add subject'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
    TextField(controller:name,decoration:const InputDecoration(labelText:'Subject name')),
    const SizedBox(height:8),TextField(controller:max,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Maximum marks')),
    const SizedBox(height:8),TextField(controller:chapters,minLines:4,maxLines:7,decoration:const InputDecoration(labelText:'Chapters (one per line)',hintText:'Electrostatics | 5 | 4\nCurrent Electricity | 4 | 3',helperText:'Format: Chapter | weightage | difficulty (1–5). Weightage defaults to 1; difficulty defaults to 3.')),
  ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:(){if(name.text.trim().isEmpty)return;final list=<Chapter>[];for(final line in chapters.text.split('\n')){final p=line.split('|');if(p.first.trim().isEmpty)continue;list.add(Chapter(p[0].trim(),p.length>1?(double.tryParse(p[1].trim())??1):1,p.length>2?(int.tryParse(p[2].trim())??3).clamp(1,5).toInt():3));}Navigator.pop(ctx,Subject(name.text.trim(),double.tryParse(max.text)??100,list));},child:const Text('Add'))]);
  return result;
}

Future<void> showResultDialog(BuildContext context,ExamStore store) async {
  final exam=TextEditingController(), subject=TextEditingController(), obtained=TextEditingController(), maximum=TextEditingController(text:'100');
  String? imagePath;
  await showDialog(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,set)=>AlertDialog(title:const Text('Record examination result'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
    TextField(controller:exam,decoration:const InputDecoration(labelText:'Exam name')),
    const SizedBox(height:8),TextField(controller:subject,decoration:const InputDecoration(labelText:'Subject')),
    const SizedBox(height:8),Row(children:[Expanded(child:TextField(controller:obtained,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Marks obtained'))),const SizedBox(width:8),Expanded(child:TextField(controller:maximum,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Out of')))]),
    const SizedBox(height:12),OutlinedButton.icon(onPressed:()async{final x=await ImagePicker().pickImage(source:ImageSource.gallery,imageQuality:80);if(x!=null){final dir=await getApplicationDocumentsDirectory();final path='${dir.path}/result_${DateTime.now().millisecondsSinceEpoch}.jpg';await x.saveTo(path);set(()=>imagePath=path);}},icon:const Icon(Icons.image_outlined),label:Text(imagePath==null?'Attach result image':'Image attached')),
  ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:(){final a=double.tryParse(obtained.text),b=double.tryParse(maximum.text);if(exam.text.trim().isEmpty||subject.text.trim().isEmpty||a==null||b==null||b<=0||a<0||a>b)return;store.addResult(ExamResult(exam.text.trim(),subject.text.trim(),a,b,DateFormat('d MMM yyyy').format(DateTime.now()),imagePath));Navigator.pop(ctx);},child:const Text('Save result'))])));
}
